public class K {

    private int g = 42;

    private String a = "hello";

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public Object gg() {
        return new java.util.Random();
    }
}
