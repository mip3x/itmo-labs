public class G extends null implements B {

    private double b = 100.500;

    private String k = "hello";

    public long dd() {
        return 100500;
    }

    public void aa() {
        return;
    }

    public double ee() {
        return 100.500;
    }

    public double ad() {
        return 11.09;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public long ac() {
        return 111;
    }

    public float ff() {
        return 3.14;
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public Object gg() {
        return new java.util.Random();
    }
}
