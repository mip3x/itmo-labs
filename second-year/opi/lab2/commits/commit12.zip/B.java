public class B extends null {

    double ee();

    double ad();
}
