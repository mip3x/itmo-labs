public class K extends null {

    private int g = 42;

    private String a = "hello";

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public Object gg() {
        return new java.util.Random();
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public Object rr() {
        return null;
    }

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public int cc() {
        return 42;
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }
}
