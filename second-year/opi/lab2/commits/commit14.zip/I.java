public class I extends K {

    private double h = 100.500;

    private double b = 100.500;

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public float ff() {
        return 3.14;
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public void aa() {
        return;
    }

    public int ae() {
        return java.lang.Math.abs(-7);
    }

    public Object pp() {
        return this;
    }

    public int af() {
        return -1;
    }

    public int cc() {
        return 39;
    }

    public void ab() {
        System.out.println("\n");
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public long ac() {
        return 111;
    }
}
