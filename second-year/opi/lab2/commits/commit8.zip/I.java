public class I extends K {

    private double h = 100.500;

    private double b = 100.500;

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public float ff() {
        return 3.14;
    }

    public void aa() {
        return;
    }

    public int ae() {
        return java.lang.Math.abs(-7);
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }
}
