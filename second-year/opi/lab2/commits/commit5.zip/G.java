public class G implements B {

    private double b = 100.500;

    private String k = "hello";

    public long dd() {
        return 100500;
    }

    public void aa() {
        return;
    }

    public double ee() {
        return 100.500;
    }

    public double ad() {
        return 11.09;
    }
}
