public interface B {

    double ee();

    double ad();
}
