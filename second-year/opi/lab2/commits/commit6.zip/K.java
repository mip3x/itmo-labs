public class K {

    private int g = 42;

    private String a = "hello";

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public Object gg() {
        return new java.util.Random();
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public void bb() {
        System.out.println(getClass().getName());
    }
}
